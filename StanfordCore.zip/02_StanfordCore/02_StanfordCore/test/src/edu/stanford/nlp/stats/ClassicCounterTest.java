package edu.stanford.nlp.stats;

/**
 * Tests for the ClassicCounter.
 * 
 * @author dramage
 */
public class ClassicCounterTest extends CounterTestBase {
  public ClassicCounterTest() {
    super(new ClassicCounter<String>());
  }
}
